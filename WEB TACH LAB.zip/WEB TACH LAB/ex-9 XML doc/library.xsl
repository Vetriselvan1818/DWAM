<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <!-- Match the root element -->
    <xsl:template match="/">

        <html>

        <head>

            <title>Library Book List</title>

            <style>

                body {
                    font-family: Arial;
                    background-color: #f2f2f2;
                    padding: 30px;
                }

                h1 {
                    text-align: center;
                }

                table {
                    width: 90%;
                    margin: auto;
                    border-collapse: collapse;
                    background-color: white;
                }

                th {
                    background-color: #333;
                    color: white;
                    padding: 10px;
                }

                td {
                    border: 1px solid black;
                    padding: 10px;
                    text-align: center;
                }

                .affordable {
                    color: green;
                    font-weight: bold;
                }

                .expensive {
                    color: red;
                    font-weight: bold;
                }

                .message {
                    text-align: center;
                    font-weight: bold;
                    font-size: 18px;
                }

            </style>

        </head>

        <body>

            <h1>LIBRARY BOOK LIST</h1>

            <table>

                <tr>
                    <th>Book Title</th>
                    <th>Author</th>
                    <th>Year</th>
                    <th>Price</th>
                    <th>Status</th>
                </tr>

                <!-- Loop through books -->
                <xsl:for-each select="Library/Book">

                    <!-- Sort by year -->
                    <xsl:sort select="year"
                              data-type="number"
                              order="ascending"/>

                    <tr>

                        <td>
                            <xsl:value-of select="title"/>
                        </td>

                        <td>
                            <xsl:value-of select="author"/>
                        </td>

                        <td>
                            <xsl:value-of select="year"/>
                        </td>

                        <td>
                            ₹<xsl:value-of select="price"/>
                        </td>

                        <td>

                            <!-- Check price -->
                            <xsl:choose>

                                <xsl:when test="price &lt;= 300">

                                    <span class="affordable">
                                        Affordable
                                    </span>

                                </xsl:when>

                                <xsl:otherwise>

                                    <span class="expensive">
                                        Expensive
                                    </span>

                                </xsl:otherwise>

                            </xsl:choose>

                        </td>

                    </tr>

                </xsl:for-each>

            </table>


            <!-- Check number of books -->

            <xsl:if test="count(Library/Book) &gt; 4">

                <p class="message">
                    More than 4 books are in the library
                </p>

            </xsl:if>

        </body>

        </html>

    </xsl:template>

</xsl:stylesheet>